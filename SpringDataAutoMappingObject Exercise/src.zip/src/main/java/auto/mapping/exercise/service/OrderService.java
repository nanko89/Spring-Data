package auto.mapping.exercise.service;

public interface OrderService {
    void addItem(String gameTitle);
}
