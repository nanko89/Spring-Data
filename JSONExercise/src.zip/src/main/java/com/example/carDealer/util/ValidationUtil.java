package com.example.carDealer.util;

public interface ValidationUtil {
    <E> boolean isValid (E entity);
}
