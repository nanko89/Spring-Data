package com.example.carDealer.service;

public interface SaleService {
    void fillData();
}
