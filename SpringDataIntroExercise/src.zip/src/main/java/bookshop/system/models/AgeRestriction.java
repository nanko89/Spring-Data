package bookshop.system.models;

public enum AgeRestriction {
    MINOR,
    TEEN ,
    ADULT;


}
