package bookshop.system.models;

public enum EditionType {
    NORMAL,
    PROMO,
    GOLD;
}
