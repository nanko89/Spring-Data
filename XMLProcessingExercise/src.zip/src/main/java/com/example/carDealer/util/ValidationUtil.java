package com.example.carDealer.util;

public interface ValidationUtil {

    <T> boolean isValid(T entity);
}
