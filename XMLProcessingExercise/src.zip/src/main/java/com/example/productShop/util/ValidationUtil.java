package com.example.productShop.util;

public interface ValidationUtil {

    <T> boolean isValid(T entity);
}
