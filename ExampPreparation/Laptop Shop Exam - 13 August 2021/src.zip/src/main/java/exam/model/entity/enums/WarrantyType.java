package exam.model.entity.enums;

public enum WarrantyType {
    BASIC, PREMIUM, LIFETIME
}
