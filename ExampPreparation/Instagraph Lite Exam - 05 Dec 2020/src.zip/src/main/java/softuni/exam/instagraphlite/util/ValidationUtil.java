package softuni.exam.instagraphlite.util;

public interface ValidationUtil {

    <T> boolean isValid(T entity);

}
